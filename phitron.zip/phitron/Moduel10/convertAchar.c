#include<stdio.h>
int main(){

 char a='8';
 printf("%d",a-'0');





    return 0;
}