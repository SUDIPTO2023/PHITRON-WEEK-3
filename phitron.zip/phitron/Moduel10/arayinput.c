#include<stdio.h>
int main (){

 char a[8];//specific size will be declare or its runtime error on online judge;
 scanf("%s",a);
 printf("%s",a);
  


    return 0;
}