#include<stdio.h>
#include<string.h>
int main(){
 char a[1000001];
 int count=0;
 scanf("%s",a);
 for (int i = 0; i < strlen(a); i++)
 {
    count=count + a[i]-'0';//we need integer value thats why we minus with '0'or 48
 }
 printf("%d",count);
 






    return 0;
}