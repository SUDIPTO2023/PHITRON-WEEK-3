#include <stdio.h>
int main (){ 

  char c[7];
 printf("%d",sizeof(c)/sizeof(char));





//   for (int i = 0; i < 7; i++)
//   {
//     scanf ("%c",&c[i]);
//   }
//   for (int i = 0; i < 7; i++)
//   {
//     printf("%c\n",c[i]);
//   }
  
  







    return 0;
}