#include<stdio.h>
#include<string.h>
int main(){

 char s[1001];
 char t[1001];
 scanf("%s",s);
 scanf("%s",t);
 int x=strlen(s);
 int y=strlen(t);
 printf("%d %d\n",x,y);
 printf("%s %s",s,t);






    return 0;
}