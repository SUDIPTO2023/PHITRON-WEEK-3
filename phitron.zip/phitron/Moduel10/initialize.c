#include <stdio.h>
int main(){
 
 char a[]="sudipto";//initialize power
 int sz=sizeof(a)/sizeof(char);
 printf("%d\n",sz);//print power without loop
 printf("%s",a);



    return 0; 
}