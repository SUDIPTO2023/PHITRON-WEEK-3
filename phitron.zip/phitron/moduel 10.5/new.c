#include <stdio.h>
#include <string.h>
int main()
{

    int t;
    scanf("%d",&t);
    while (t--)
    {

         
        char a[101];

         

        scanf("%s", a);
        strlen(a);
        if (strlen(a) < 10)
        {
            printf("%s\n", a);
        }
        else
        {
            int l;
            l = strlen(a) - 2;
            printf("%c%d%c\n", a[0], l, a[strlen(a) - 1]);
        }
    }

    return 0;
}