#include <stdio.h>
int main()
{

    int n, min, max  ;
    scanf("%d", &n);
    int a[n];
    
    for (int i = 0; i < n; i++)
    {

        scanf("%d", &a[i]);
    }

    min = a[0];
    max = a[0];
    int x=0;
    int y=0;

    for (int i = 0; i < n; i++)
    {

        if (min > a[i])
        {
            min = a[i];
            x++;
             
        }
        if (max < a[i])
        {
            max = a[i];
             y++;
        }
    }
    printf("%d %d",  x,y);

    return 0;
}