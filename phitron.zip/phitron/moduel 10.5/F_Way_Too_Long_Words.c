#include <stdio.h>
#include <string.h>
int main()
{
    
    int x;
    char a[101];

    scanf("%d",&x);


    int t;
    while (t--)
    {
         scanf("%s", a);
        strlen(a);
        if (strlen(a) < 10)
        {
            printf("%s\n", a);
        }
        else
        {
            int l;
            l = strlen(a) - 2;
            printf("%c%d%c\n", a[0], l, a[strlen(a) - 1]);
        }
    }
    









    // for (int i = 0; i < x; i++)
    // {
    //     scanf("%s", a);
    //     strlen(a);
    //     if (strlen(a) < 10)
    //     {
    //         printf("%s\n", a);
    //     }
    //     else
    //     {
    //         int l;
    //         l = strlen(a) - 2;
    //         printf("%c%d%c\n", a[0], l, a[strlen(a) - 1]);
    //     }
    // }

    return 0;
}