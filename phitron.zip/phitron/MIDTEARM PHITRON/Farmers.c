#include <stdio.h>
int main()
{
    int t;
    scanf("%d", &t);
    int m1, m2, d, totalF, ans;

    for (int i = 1; i <= t; i++)
    {
        scanf("%d %d %d", &m1, &m2, &d);
        totalF = m1 + m2;
        int totalday = (m1 * d) / totalF;
        ans = d - totalday;
        printf("%d\n", ans);
    }

    return 0;
}