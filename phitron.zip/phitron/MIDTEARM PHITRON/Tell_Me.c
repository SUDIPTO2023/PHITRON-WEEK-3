#include <stdio.h>
int main()
{
    int t, n;
    scanf("%d", &t);

    for (int i = 0; i < t; i++)
    {
        scanf("%d", &n);
        long long a[n];
        for (int i = 0; i < n; i++)
        {
            scanf("%lld", &a[i]);
        }
        int ran, flag = 0;
        scanf("%d", &ran);
        for (int i = 0; i < n; i++)
        {
            if (a[i] == ran)
            {
                flag++;
                break;
            }
        }
        if (flag == 0)
        {
            printf("NO\n");
        }
        else
        {
            printf("YES\n");
        }
    }

    return 0;
}