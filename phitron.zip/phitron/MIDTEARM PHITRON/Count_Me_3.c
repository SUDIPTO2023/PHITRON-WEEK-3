#include<stdio.h>
#include<string.h>
int main(){


  int t;
  scanf("%d",&t);
  
  for (int i = 1; i <=t; i++)
  {
     char s[10001];
     scanf("%s",s);
    int  cntA=0,cnta=0,cntd=0;
  for (int i = 0; i < strlen(s); i++)
  {
    if (s[i]>=97 && s[i]<=122)
    {
        cnta ++;
    } else if (s[i]>=65 && s[i]<=90)
    {
        cntA++;
    }else
    {
        cntd++;
    }
    
   
    
  }
  printf("%d %d %d\n",cntA,cnta,cntd);
  }
  
   









    return 0;
}