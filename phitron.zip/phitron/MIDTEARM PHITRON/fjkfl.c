#include<stdio.h>
int main(){

 printf("%d",'a'-97);


    return 0;
}