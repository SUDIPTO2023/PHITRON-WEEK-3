#include<stdio.h>
#include<string.h>
int main(){

 int n;
 scanf("%d",&n);
 int a[n];
 for (int i = 0; i < n; i++)
 {
    scanf("%d",&a[i]);
 }
 int cnt[7]={0};//cnt er valu joto tar agey porjonto array er sorboccho man hobey example:[7]taholey arrey er sorboccho man hobey6;
 for (int i = 0; i < n; i++)
 {

    int val=a[i];
    cnt[val] ++;
    
    
 }
 
   for (int i = 0; i < 7; i++)
   {
    printf("%d : %d\n",i,cnt[i]);
   }
   






    return 0;
}