#include<stdio.h>
#include<string.h>
int main(){
 
 char a[100],b[1000];
 scanf("%s %s",a,b);
//  for (int i = 0; i <= strlen(b); i++) //this is main logic how to work
//  {
//       a[i]=b[i];
//  }
 

  strcpy(a,b);/*or we can use built in function*/

 printf("%s",a);

    return 0;
}